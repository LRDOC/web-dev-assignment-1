import React from 'react';
import Modules from '../Modules';

export default function Home() {
    return (
        <div>
            <h1>Pancake Cooking Home</h1>
            <Modules />
            {/* i was hungry when doing this and saw in the example with pancakes */}
        </div>
    );
}
