import React from 'react';

export default function Modules() {
    return (
        <div>
            <h1>Modules</h1>
            <p>List of course modules will be here.</p>
        </div>
    );
}
